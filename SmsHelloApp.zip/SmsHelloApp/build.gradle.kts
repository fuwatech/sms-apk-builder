// Top-level build file
plugins {
    // empty; plugins are applied in module build.gradle.kts
}
