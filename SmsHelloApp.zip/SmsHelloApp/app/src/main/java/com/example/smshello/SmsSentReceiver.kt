package com.example.smshello

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.SmsManager
import android.widget.Toast

class SmsSentReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (resultCode) {
            Activity.RESULT_OK -> Toast.makeText(context, "SMS sent", Toast.LENGTH_LONG).show()
            SmsManager.RESULT_ERROR_NO_SERVICE -> Toast.makeText(context, "No service", Toast.LENGTH_LONG).show()
            SmsManager.RESULT_ERROR_RADIO_OFF -> Toast.makeText(context, "Radio off", Toast.LENGTH_LONG).show()
            SmsManager.RESULT_ERROR_GENERIC_FAILURE -> Toast.makeText(context, "Send failed", Toast.LENGTH_LONG).show()
            else -> Toast.makeText(context, "Send failed", Toast.LENGTH_LONG).show()
        }
    }
}
