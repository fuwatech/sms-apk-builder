package com.example.smshello

object Actions {
    const val SMS_SENT = "com.example.smshello.SMS_SENT"
}
