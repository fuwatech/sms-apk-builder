# SMS Hello App (Android)
Minimal one-screen app:
- Enter a phone number
- Tap "Send Hello"
- Sends SMS text "Hello" using the device SIM (SmsManager)

## Build
1. Open the folder in Android Studio (Giraffe/Koala or newer)
2. Let it sync Gradle
3. Run on a physical Android device (SMS won't work on most emulators)
4. First send will ask for SMS permission

## Notes
- Android only
- No server, no WorkManager, just immediate send
